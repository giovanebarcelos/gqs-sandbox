# Build Instruction


```
mvn clean package
and build the instruction .
```

# Deploy instruction

Deploy ```target/WebApp.war``` on Tomcat properly for better experience.

# Fonte

https://github.com/DeekshithSN/sample-web-application

# Testing

Testing task #331  